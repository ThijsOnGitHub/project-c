exports.serverLogin={
        host:"db4free.net",
        user:"adminrooster",
        password:"Hogeschool",
        database:"roosterit"
}