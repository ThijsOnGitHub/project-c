import React from 'react';
import logo from './logo.svg';
import './App.css';
import DataTest from "./Pages/DataTest";

function App() {
  return (
    <div>
      <DataTest/>
    </div>
  );
}

export default App;
